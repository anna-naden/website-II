curl "https://cookpolitical.com/sites/default/files/2020-10/EC%20Ratings.102820.pdf" >~/projects/website-II/election/cook.pdf
